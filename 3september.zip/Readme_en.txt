Could you became the ultimate master of calendar turning?!
Based on a meme song by Michail Shufutinsky https://www.youtube.com/watch?v=Kv-tbdVOuOA

Put valve_addon folder into Half-Life folder. In game Options->Video->Enable custom content. In the console type: map calendar

------
Xash3D ONLY!
------
Put maps � sound folders into valve/custom
------

Credits
dorms map rmf from megacool Induction mod https://www.moddb.com/mods/half-life-induction

Toilet prefab from Rimpository on twhl.info
